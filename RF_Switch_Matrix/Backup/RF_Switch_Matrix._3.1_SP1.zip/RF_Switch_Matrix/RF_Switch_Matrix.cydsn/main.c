/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <cli.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <main.h>

int switchFreq          =   10000;          // Set default switch speed to 10KHz
bool power              =   false;          // When device turns on, set power to off

typedef struct node {       //node for switch
    uint16 number;
    struct node *next;
} node_t;

node_t *head;
node_t *curr;

void nextSwitch(void);
void wait(void);


//Setup typdef for CLI interface states
typedef enum {HOME, SET_FREQ, SET_SWITCH} status_t;
status_t status= HOME;

CY_ISR(rx_int) {
    uint32 source;
    static uint8 i=0;
    char data;
    static char *input="";
    
    data = UART_ReadRxData();    
    switch(status) {
        case HOME:
            switch(data) {
                case '1':
                    if(power) {
                        power = false;
                        //update controller
                    } else {
                        power = true;
                        //update controller
                    }
                    break;
                case '2':
                    break;
                case '3':
                    break;
                default:
                    sendString("Invalid input\r\n");
            }
            break;
        case SET_FREQ:
            //gather input until enter is pressed
            input[i]=data;
            i++;
            if(data =='\r' || data=='\n') {
                i=0;
                input="";
            }
                
            break;
        case SET_SWITCH:
            switch(data) {
                case 'a':       //activate or deactive the first switch
                    
                    break;
                case 'b':
                    break;
                case 'c':
                    break;
                default:
                    sendString("Invalid input\r\n");
            }
            break;
    }
}


int main() {    
    initHardware();
        
    for(;;) {                   // Loop through all the switches
        nextSwitch();
        wait();
    }
}

void updateOutput(int switchNo) {
    
}

/* Switch struct control. */
/*Inialises all switches to be on, creates the linked list
 * and links all the switches together in a standard order.
 */
void initSwitches(void) {
    int i;
    node_t *tmp = NULL;
    head = curr = malloc(sizeof(node_t));
    head->number = 0;
    for(i=1; i<MAX_SWITCHES; i++) {
        tmp = malloc(sizeof(node_t));
        tmp->number=i;
        curr->next = tmp;
        curr=tmp;
    }
    curr->next = head;
}
void nextSwitch(void) {
    
}
void gotoHead(void) {
    
}
void addSwitch(int switchNo) {
    
}
void removeSwitch(int switchNo) {
    
}


void wait(void) {
    
}


void initHardware(void) {
    CyGlobalIntEnable;
    UART_Start();                   //Setup UART comm.
    uartRx_isr_StartEx(rx_int);     //Inialise Rx ISR
    OutputReg_Write(0u);            //Set all vaules to 0
}

/* [] END OF FILE */
