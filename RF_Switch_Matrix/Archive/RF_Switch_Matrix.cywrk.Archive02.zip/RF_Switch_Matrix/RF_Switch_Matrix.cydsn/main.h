/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define MAX_SWITCHES        16              // Maximum no. switches is 16
#define MAX_FREQ            400000          // Maximum frequency is 40KHz 

void initHardware(void);

/* [] END OF FILE */
