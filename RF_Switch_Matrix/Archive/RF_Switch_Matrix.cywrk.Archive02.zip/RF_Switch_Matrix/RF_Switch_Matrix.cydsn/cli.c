/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <cli.h>
#include <stdbool.h>

/** void sendString(char* string)
  * @param:
  *     pointer to a array of char
  *
  * Writes the parsed string to the Tx USB conneciton
  *
  */
void sendString(char* string) {
    int i=0;
    while(string[i] != '\0') {
        UART_WriteTxData(string[i]);
        i++;
    }
}


bool checkPower() {
    return true;
}

/** void dispMenuHelp(void)
  * @param:
  *     none
  *
  * Prints out the help menu
  *
  */
void dispMenuHelp(void) {
    char* string;
    if(checkPower() == true) {
        sendString("1. Turn off switch matrix\r\n");
    } else {
        sendString("1. Turn on switch matrix\r\n");
    }
    sendString("2. Set switching frequency\r\n");
    sendString("3. Change active swiches\r\n");
}

/* [] END OF FILE */
